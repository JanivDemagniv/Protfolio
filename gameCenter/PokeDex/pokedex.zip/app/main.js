import { listBuilder, loaderPage } from "./pageBuilder.js";

//creating the page, plus loading animation
listBuilder();
window.addEventListener('load', loaderPage())

